#ifndef SHOW_RECRUITMENT_UI_H
#define SHOW_RECRUITMENT_UI_H

#include <iostream>
#include <vector>
#include "Recruitment.h"

class ShowRecruitmentUI {
public:
    static void startInterface(vector<Recruitment>& recruitment, string name);
};

#endif 