#ifndef SIGN_OUT_UI_H
#define SIGN_OUT_UI_H

#include <string>
#include "Member.h"

/*
 * �α׾ƿ� boundary class
 */


class SignOutUI {
public:
    static void signOutUI(Member& member);
};
#endif