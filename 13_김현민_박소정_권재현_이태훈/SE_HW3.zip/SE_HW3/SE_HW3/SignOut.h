#ifndef SIGN_OUT_H
#define SIGN_OUT_H

#include "Member.h"

/*
 * �α׾ƿ� control class
 */


class SignOut {
public:
    static string signOut(Member& member);
};
#endif
